let vragen = ["welke is een schimmel kaas","op welke vraag zitten we","heb je deze vraag goed?","wat is system of a down","Wie gaat de kaas salami oorlog winnen"]
let antwoorden = [["cheddar","drie","nee","een schimmal kaas","salami"],["mozzarella","honderd","echt niet","een salami","iedereen"],["gouda","de uhh eerste ik weet het niet","ik heb hem fout","een soort slak","niemand"]]
let juist = ["brie","twee","ja","een band","kaas"]
let vraag = 0
let score = 0

console.log(vragen, antwoorden, juist, vraag, score)